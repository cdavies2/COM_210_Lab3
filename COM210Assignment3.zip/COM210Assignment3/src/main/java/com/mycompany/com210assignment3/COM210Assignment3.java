package com.mycompany.com210assignment3;

import javax.swing.JOptionPane;

public class COM210Assignment3 
{
    int maxSize;
    int[] stackArray;
    int top;

    //here we are checking if brackets are balanced
    public static void main(String[] args) 
    {
        COM210Assignment3 stack1= new COM210Assignment3(100);
        
        String s=JOptionPane.showInputDialog("Enter a string with brackets");
        int stringLength=s.length();//get the length of the string to determine how many times the loop iterates
     //code to test the charAt method
     //System.out.println(s.charAt(0));
     char p;
     String d;
     for(int i=0; i<stringLength; i++)
     {
         p=s.charAt(i);//each time the loop iterates, the value of the current character is saved
         d= String.valueOf(p); //converts characters to strings so comparison can occur
         if(d.equals("["))
         {
             stack1.push(0);
         } 
         
         if(d.equals("]"))
         {
             stack1.pop(0);
         }    
     }    
     
     //check for underflow error, if true then unbalanced
     if(stack1.isEmpty()==true)
     {
         System.out.println("The string is balanced");
     }    
     else
     {
         System.out.println("The string is not balanced");
     }    
    }   
    
    public COM210Assignment3(int s)
    { //this allows us to make different stacks with very different parameters
        maxSize=s;
        stackArray=new int[maxSize];
        top=-1; //no items yet
    }        
    
    public boolean push(int j) //put item on top of stack
    {
      stackArray[++top]=j; //++top means we're incrementing top before executing the rest of the line
      return true; //the push was successful
    }
    
    public int pop(int i)
    {
        return stackArray[top--];//access item, then decrement top
    }     
    
    public boolean isEmpty()//true if stack is empty (underflow)
    {
        return(top==-1);
    }        
    
    public boolean isFull()//true if stack is full (overflow)
    {
        return(top==maxSize-1);
    } 
    
      
}


